Here is the converted code:
```
package com.javachap.service;

import org.springframework.stereotype.Service;

/**
 * Base Service
 * @author Varma
 */
@Service
public interface Service {

}
```
Note that this code uses Spring's `@Service` annotation to indicate that the class is a service and should be registered with the Spring container. The `Serializable` interface is also removed, as it is not necessary in Spring 6.