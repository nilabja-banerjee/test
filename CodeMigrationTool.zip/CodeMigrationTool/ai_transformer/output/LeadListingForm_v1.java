Here is the converted code:
```
package com.javachap.web.model;

import org.springframework.stereotype.Component;

@Component
public class LeadListingForm {

    private Long leadId = null;

    public void setLeadId(Long leadId) {
        this.leadId = leadId;
    }

    public Long getLeadId() {
        return leadId;
    }

    private String[] leadIds = null;

    public void setLeadIds(String[] leadIds) {
        this.leadIds = leadIds;
    }

    public String[] getLeadIds() {
        return leadIds;
    }
}
```
Note that the `BaseForm` class has been removed, as it is not necessary in Spring MVC with annotations. Also, the `serialVersionUID` field has been removed, as it is not used in Spring MVC. Finally, the `getLeadId()` and `setLeadId()` methods have been modified to use the `Long` type instead of `String`.