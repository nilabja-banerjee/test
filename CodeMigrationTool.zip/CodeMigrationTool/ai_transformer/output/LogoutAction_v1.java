Here is the converted code:
```
package com.javachap.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LogoutAction {
    @GetMapping("/logout")
    public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) {
        request.getSession().invalidate();
        return new ModelAndView("login");
    }
}
```
Explanation:

* The `LogoutAction` class has been annotated with `@Controller`, which indicates that it is a Spring MVC controller.
* The `logout()` method has been annotated with `@GetMapping("/logout")`, which maps the HTTP GET request to the `/logout` URL.
* The `request.getSession().invalidate()` line invalidates the current session, and the `return new ModelAndView("login");` line returns a `ModelAndView` object that represents the "login" view.
* The `ModelAndView` object contains the name of the view to be rendered, as well as any data that should be passed to the view. In this case, the view is simply the "login" page.