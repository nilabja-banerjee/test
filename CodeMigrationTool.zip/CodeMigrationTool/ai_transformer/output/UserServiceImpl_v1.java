package com.javachap.service.impl;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.javachap.domain.User;
import com.javachap.service.UserService;
import com.javachap.utils.HibernateUtils;

@Service
public class UserServiceImpl implements UserService {

	private static final long serialVersionUID = 4889152297004460837L;

	private String AUTHENTICATION_QUERY = "from User user where user.email= :Email and user.password = :Password";

	@Transactional
	public User authenticate(String email, String password) {
		User user = null;
		try (Session session = HibernateUtils.currentSession()) {
			Query query = session.createQuery(AUTHENTICATION_QUERY);
			query.setParameter("Email", email);
			query.setParameter("Password", password);
			List<User> list = (List<User>) query.list();
			if (list.size() == 1) {
				user = (User) list.get(0);
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return user;
	}

	@Transactional
	public User getUser(Long userId) {
		User user = null;
		try (Session session = HibernateUtils.currentSession()) {
			user = (User)session.get(User.class, userId);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return user;
	}

	@Transactional
	public User save(User user) {
		try (Session session = HibernateUtils.currentSession()) {
			session.save(user);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return user;
	}
}
