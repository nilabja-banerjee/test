```
package com.javachap.service;

import org.springframework.stereotype.Component;

@Component
public class ServiceUtils {

    private static final UserService userService = new UserServiceImpl();
    private static final LeadService leadService = new LeadServiceImpl();
    private static final CategoryService categoryService = new CategoryServiceImpl();

    public static UserService getUserService() {
        return userService;
    }

    public static LeadService getLeadService() {
        return leadService;
    }

    public static CategoryService getCategoryService() {
        return categoryService;
    }
}
```