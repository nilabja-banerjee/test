Here is the converted code:
```
package com.javachap.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.javachap.domain.Lead;
import com.javachap.domain.User;
import com.javachap.service.LeadService;
import com.javachap.service.ServiceUtils;
import com.javachap.web.model.LeadListingForm;

@Controller
public class LeadListingAction {

    @GetMapping("/leads")
    public ModelAndView list(@RequestParam(value = "action", required = false) String action, HttpServletRequest request, HttpServletResponse response) {
        User user = (User) request.getSession().getAttribute("user");
        List<Lead> leadList = ServiceUtils.getLeadService().getLeadsByUser(user);
        request.setAttribute("leadList", leadList);
        return new ModelAndView("leads");
    }

    @PostMapping("/leads")
    public String delete(@RequestParam(value = "action", required = false) String action, @RequestParam(value = "leadId", required = false) Long leadId, HttpServletRequest request, HttpServletResponse response) {
        if ("delete".equalsIgnoreCase(action)) {
            LeadService leadService = ServiceUtils.getLeadService();
            boolean deleteSuccessfull = false;
            if (leadId != null && leadId > 0) {
                Lead lead = leadService.getLead(leadId);
                if (lead != null) {
                    leadService.delete(lead);
                    ActionMessages messages = new ActionMessages();
                    messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("message.lead.delete"));
                    saveMessages(request, messages);
                    deleteSuccessfull = true;
                }
            }
            if (!deleteSuccessfull) {
                ActionErrors errors = new ActionErrors();
                errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.lead.deleted"));
                saveErrors(request, errors);
            }
        } else if ("deleteLeads".equalsIgnoreCase(action)) {
            String[] leadIds = request.getParameterValues("leadIds");
            for (String leadIdString : leadIds) {
                Long leadId = Long.parseLong(leadIdString);
                delete(leadId, request);
            }
        }
        return "redirect:/leads";
    }
}
```
Note that this code uses Spring MVC annotations instead of Struts tags and actions. It also removes the dependency on the `LeadListingForm` class and uses a `ModelAndView` object to pass data between methods. Additionally, it uses the `@GetMapping` and `@PostMapping` annotations to define the HTTP request mappings for the controller methods.