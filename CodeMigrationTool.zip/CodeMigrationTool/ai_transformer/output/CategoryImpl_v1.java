Here is the converted code:
```
package com.javachap.domain.impl;

import org.springframework.stereotype.Component;

@Component
public class CategoryImpl implements Category {

    private String name;
    private String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "CategoryImpl[description=" + description + ", name=" + name + "]";
    }
}
```
Note that the `DomainImpl` class has been removed, as it is not necessary in Spring. Also, the `serialVersionUID` field has been removed, as it is not used in Spring. Finally, the `toString()` method has been modified to use a more concise and readable format.