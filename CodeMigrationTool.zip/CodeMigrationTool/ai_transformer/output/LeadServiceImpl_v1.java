package com.javachap.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.javachap.domain.Lead;
import com.javachap.domain.User;
import com.javachap.service.LeadService;
import com.javachap.utils.HibernateUtils;

@Service
public class LeadServiceImpl implements LeadService {

	private static final String LEADS_BY_USER_QUERY = "from Lead lead where lead.owner.id = :UserId";

	@Transactional
	public void delete(Lead lead) {
		HibernateUtils.currentSession().delete(lead);
	}

	@Transactional
	public Lead getLead(Long id) {
		return HibernateUtils.currentSession().get(Lead.class, id);
	}

	@Transactional
	public Lead save(Lead lead) {
		HibernateUtils.currentSession().saveOrUpdate(lead);
		return lead;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Lead> getLeadsByUser(User user) {
		Query query = HibernateUtils.currentSession().createQuery(LEADS_BY_USER_QUERY);
		query.setParameter("UserId", user.getId());
		return (List<Lead>) query.list();
	}
}
