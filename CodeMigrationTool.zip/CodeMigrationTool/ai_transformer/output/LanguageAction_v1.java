Here is the converted code:
```
package com.javachap.web.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LanguageAction {

    @GetMapping("/language")
    public String execute(@ModelAttribute("languageForm") LanguageForm languageForm,
                          HttpServletRequest request,
                          HttpServletResponse response,
                          RedirectAttributes redirectAttributes) {
        Locale locale = null;
        if ("french".equals(languageForm.getLanguage())) {
            locale = Locale.FRENCH;
        } else {
            locale = Locale.ENGLISH;
        }
        request.getSession().setAttribute("display", locale);
        return "leadListing";
    }
}
```
Note that this code uses Spring MVC annotations instead of Struts actions and forms, and it removes all Struts dependencies. The `LanguageAction` class is annotated with `@Controller`, which indicates that it is a Spring controller. The `execute()` method is annotated with `@GetMapping("/language")`, which maps the HTTP GET request to the `/language` URL. The method takes three arguments:

* `@ModelAttribute("languageForm")` - This annotation binds the `LanguageForm` object to the HTTP request parameters.
* `HttpServletRequest` - This argument provides access to the HTTP request and its attributes.
* `HttpServletResponse` - This argument provides access to the HTTP response and its attributes.
* `RedirectAttributes` - This argument allows you to redirect the user to a different URL after the method has completed.

Inside the `execute()` method, we first check if the language is French or English by checking the value of the `languageForm.getLanguage()` method. We then set the locale based on this value and store it in the session using the `request.getSession().setAttribute("display", locale)` method. Finally, we return a string that represents the URL to redirect the user to after the method has completed. In this case, we are returning the `"leadListing"` URL.