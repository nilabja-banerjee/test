package com.javachap.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public abstract class SecuredAction {

    @GetMapping("/")
    public ModelAndView execute(HttpServletRequest request, HttpServletResponse response) {
        if (request.getSession().getAttribute("user") != null) {
            return lmsExecute(request, response);
        } else {
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.label.authRequired"));
            saveErrors(request, errors);
            return new ModelAndView("login");
        }
    }

    @PostMapping("/")
    public ModelAndView lmsExecute(HttpServletRequest request, HttpServletResponse response) {
        // Implement your logic here
        return null;
    }
}
