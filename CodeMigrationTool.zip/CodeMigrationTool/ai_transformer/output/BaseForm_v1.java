Here is the converted code:
```
package com.javachap.web.model;

import org.springframework.stereotype.Component;

@Component
public class BaseForm {

	private String action = null;

    public void setAction(String action){
        this.action = action;
    }

    public String getAction(){
       return (this.action);
    }
}
```
Note that the `serialVersionUID` field has been removed, as it is not needed in Spring MVC. Also, the `extends ActionForm` clause has been removed, as Spring MVC does not use Struts' action form class. Finally, the `@Component` annotation has been added to indicate that this class is a Spring component.