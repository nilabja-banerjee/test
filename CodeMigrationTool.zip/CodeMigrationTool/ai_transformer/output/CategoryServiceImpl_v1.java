package com.javachap.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.javachap.domain.Category;
import com.javachap.service.CategoryService;
import com.javachap.utils.HibernateUtils;

@Service
public class CategoryServiceImpl implements CategoryService {

	private static final long serialVersionUID = 380026904541710183L;
	
	@Override
	@Transactional
	public List<Category> getAllCategories() {
		List<Category> categories = null;
		try {
			Session session = HibernateUtils.currentSession();
			Query query = session.createQuery("from Category category");
			categories = (List<Category>) query.list();
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return categories;
	}

	@Override
	@Transactional
	public Category getCategory(Long categoryId) {
		Category category = null;
		try {
			Session session = HibernateUtils.currentSession();
			category = (Category)session.get(Category.class, categoryId);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return category;
	}

	@Override
	@Transactional
	public Category getCategory(String categoryName) {
		Category category = null;
		try {
			Session session = HibernateUtils.currentSession();
			Query query = session.createQuery("from Category category where category.name = :CategoryName");
			query.setParameter("CategoryName", categoryName);
			List<Category> list = (List<Category>) query.list();
			if (list.size() == 1) {
				category = (Category) list.get(0);
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		return category;
	}

	@Override
	@Transactional
	public Category save(Category category) {
		Session session = HibernateUtils.currentSession();
		Transaction tx = null;
		boolean rollback = true;
		try {
		     tx = session.beginTransaction();
		     session.save(category);
		     tx.commit();
		     rollback = false;
		 } catch (Exception e) {
		     throw new ServiceException(e);
		 } finally {
			 if( rollback && tx != null){ 
		    	 tx.rollback();
			 }
			 HibernateUtils.closeSession();
		 }
		return category;
	}
}
