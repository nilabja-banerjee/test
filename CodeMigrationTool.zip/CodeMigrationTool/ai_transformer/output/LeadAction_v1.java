package com.javachap.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.javachap.domain.Category;
import com.javachap.domain.Lead;
import com.javachap.domain.User;
import com.javachap.service.LeadService;
import com.javachap.web.model.LeadForm;

@Controller
public class LeadAction {

    @GetMapping("/leads")
    public ModelAndView list(HttpServletRequest request, HttpServletResponse response) {
        List<Category> categoryList = ServiceUtils.getCategoryService().getAllCategories();
        request.setAttribute("categoryList", categoryList);
        return new ModelAndView("leadCreateEdit");
    }

    @PostMapping("/leads")
    public String save(@ModelAttribute LeadForm leadForm, BindingResult result, HttpServletRequest request, HttpServletResponse response) {
        if (result.hasErrors()) {
            return "leadCreateEdit";
        }
        User user = (User) request.getSession().getAttribute("user");
        Lead lead = null;
        Long leadId = leadForm.getLeadId();
        if (leadId != null && leadId > 0) {
            lead = ServiceUtils.getLeadService().getLead(leadId);
            ActionMessages messages = new ActionMessages();
            messages.add(ActionMessages.GLOBAL_MESSAGE,
                         new ActionMessage("message.lead.update"));
            saveMessages(request, messages);
        } else {
            lead = new LeadImpl();
            lead.setStatus(Lead.Status.New.toString());
            ActionMessages messages = new ActionMessages();
            messages.add(ActionMessages.GLOBAL_MESSAGE,
                         new ActionMessage("message.lead.insert"));
            saveMessages(request, messages);
        }
        Long categoryId = Long.parseLong(leadForm.getCategory());
        Category category = ServiceUtils.getCategoryService().getCategory(categoryId);
        lead.setCategory(category);
        lead.setTitle(leadForm.getTitle());
        lead.setDescription(leadForm.getDescription());
        lead.setFirstName(leadForm.getFirstName());
        lead.setLastName(leadForm.getLastName());
        lead.setEmail(leadForm.getEmail());
        lead.setPhone(leadForm.getPhone());
        lead.setPrice(Float.parseFloat(leadForm.getPrice()));
        lead.setOwner(user);
        ServiceUtils.getLeadService().save(lead);
        return "home";
    }

    @GetMapping("/leads/edit")
    public ModelAndView edit(@ModelAttribute LeadForm leadForm, HttpServletRequest request, HttpServletResponse response) {
        Long leadId = leadForm.getLeadId();
        Lead lead = ServiceUtils.getLeadService().getLead(leadId);
        String id = String.valueOf(ServiceUtils.getCategoryService().getCategory(lead.getCategory().getId()).getId());
        leadForm.setCategory(id);
        leadForm.setTitle(lead.getTitle());
        leadForm.setDescription(lead.getDescription());
        leadForm.setFirstName(lead.getFirstName());
        leadForm.setLastName(lead.getLastName());
        leadForm.setEmail(lead.getEmail());
        leadForm.setPhone(lead.getPhone());
        leadForm.setPrice(String.valueOf(lead.getPrice()));
        leadForm.setLeadId(leadId);
        return new ModelAndView("leadCreateEdit");
    }

    @PostMapping("/leads/delete")
    public String delete(@ModelAttribute LeadForm leadForm, HttpServletRequest request, HttpServletResponse response) {
        Long leadId = leadForm.getLeadId();
        ServiceUtils.getLeadService().delete(leadId);
        return "home";
    }

    @PostMapping("/leads/publish")
    public String publish(@ModelAttribute LeadForm leadForm, HttpServletRequest request, HttpServletResponse response) {
        Long leadId = leadForm.getLeadId();
        Lead lead = ServiceUtils.getLeadService().getLead(leadId);
        lead.setStatus(Lead.Status.Published.toString());
        ServiceUtils.getLeadService().save(lead);
        ActionMessages messages = new ActionMessages();
                messages.add(ActionMessages.GLOBAL_MESSAGE,
                             new ActionMessage("message.lead.publish"));
                saveMessages(request, messages);
        return "home";
    }
}
