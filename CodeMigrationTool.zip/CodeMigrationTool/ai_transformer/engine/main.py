from .transformer import run_transformation

if __name__ == "__main__":
    run_transformation()