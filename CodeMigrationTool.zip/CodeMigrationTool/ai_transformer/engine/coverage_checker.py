import os
import re
from .utils import logger, call_model, render_prompt, load_prompt


def check_coverage(source_code, generated_code, reviewer_model, llm_settings, prompt_dir, context_id):
    """
    Use the reviewer model to detect gaps between the original and generated code.
    Expected output format (from model):
    - Coverage: 87%
    - Issues:
      - Missing validation for user input
      - Exception handling not implemented
    """
    prompt_template = load_prompt(os.path.join(prompt_dir, "check_coverage.txt"))
    context = {
        "source_code": source_code,
        "generated_code": generated_code,
        "context_id": context_id
    }
    logger.info(f"[{context_id}] Sending source and generated code to reviewer model.")
    prompt = render_prompt(prompt_template, context)

    logger.info(f"[{context_id}] Sending source and generated code to reviewer model.")
    suggestions = call_model(prompt, reviewer_model, llm_settings)
    logger.debug(f"[{context_id}] Raw model response:\n{suggestions}")

    # Parse coverage percentage from response
    coverage_match = re.search(r"Coverage\s*[:\-]?\s*(\d+)%", suggestions)
    coverage = int(coverage_match.group(1)) if coverage_match else 0

    # Extract issues list
    issues = []
    issue_section = suggestions.split("Issues:")[-1] if "Issues:" in suggestions else ""
    for line in issue_section.strip().splitlines():
        line = line.strip()
        if line.startswith("-") or line.startswith("•"):
            issues.append(line.lstrip("-•").strip())

    return coverage, issues


def apply_feedback(source_code, generated_code, suggestions, primary_model, llm_settings, prompt_dir, context_id):
    """
    Use the primary model to improve code using reviewer suggestions.
    """
    prompt_template = load_prompt(os.path.join(prompt_dir, "apply_feedback.txt"))
    context = {
        "source_code": source_code,
        "initial_generated_code": generated_code,
        "review_feedback": suggestions,
        "context_id": context_id
    }
    prompt = render_prompt(prompt_template, context)

    logger.info(f"[{context_id}] Applying feedback via primary model.")
    improved_code = call_model(prompt, primary_model, llm_settings)
    return improved_code
