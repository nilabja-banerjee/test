package com.javachap.domain;

public interface Category extends Domain {

	String getName();

	void setName(String name);

	String getDescription();

	void setDescription(String description);
}